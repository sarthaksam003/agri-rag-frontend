import { useEffect, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/features/auth/hooks/useAuth";
import { authApi } from "@/features/auth/api/apiAuth";
import { HERO_IMAGE_URLS } from "./pageBg"
// Adjust this import to wherever logo.png actually lives in your assets folder
import logo from "@/assets/logo.png";
import cdacLogo from "@/assets/cdacLogo.png";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "";

// Pool of Indian farming photos — one is picked at random each time this
// page mounts (i.e. on every refresh). Swap any of these for your own
// assets whenever you have them; keep the array non-empty.

function pickRandomHeroImage() {
    return HERO_IMAGE_URLS[
        Math.floor(Math.random() * HERO_IMAGE_URLS.length)
    ];
}

const FEATURE_CHIPS = [
    { icon: "🌾", label: "Fertilizer & irrigation plans" },
    { icon: "🐛", label: "Pest & disease ID" },
    { icon: "📜", label: "Govt. scheme eligibility" },
];

export function LoginPage() {
    const { isLoading, isAuthenticated, isError } = useAuth();
    const location = useLocation();

    // Lazy initializer so this only runs once per mount (i.e. changes on
    // every page refresh) rather than on every re-render.
    const [heroImage] = useState(pickRandomHeroImage);

    useEffect(() => {
        document.title = "Sign in | AgriChat";
    }, []);

    if (isLoading) {
        return (
            <main className="flex min-h-screen items-center justify-center bg-[#10162B]">
                <div className="flex flex-col items-center gap-3">
                    <span className="h-8 w-8 animate-spin rounded-full border-2 border-[#E5B65C]/25 border-t-[#E5B65C]" />
                    <p className="text-sm text-white/60">Loading...</p>
                </div>
            </main>
        );
    }

    if (isAuthenticated) {
        const from = location.state?.from || "/chat";

        return <Navigate to={from} replace />;
    }

    const handleGoogleLogin = async () => {
        try {
            const authorizationUrl = await authApi.getGoogleAuthorizationUrl();
            window.location.assign(authorizationUrl);
        } catch (error) {
            console.error("Google login failed:", error);
        }
    };

    return (
        <main className="flex min-h-screen w-full flex-col md:flex-row">
            <style>{`
                @keyframes agrichat-float {
                    0%, 100% { transform: translateY(0px); }
                    50% { transform: translateY(-10px); }
                }
                .agrichat-float { animation: agrichat-float 6s ease-in-out infinite; }
            `}</style>

            {/* LEFT: image + brand story panel */}
            <div className="relative hidden overflow-hidden md:flex md:w-[58%] md:flex-col md:justify-between lg:w-[60%]">
                <img
                    key={heroImage}
                    src={heroImage}
                    alt="Farmer working in a field in India"
                    className="absolute inset-0 h-full w-full object-cover"
                />
                {/* dark brand overlay for legibility */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#10162B]/95 via-[#10162B]/78 to-[#10162B]/35" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />

                {/* wordmark */}
                <div className="relative z-10 flex items-center gap-3 px-10 pt-10 lg:px-14 lg:pt-12">
                    <div className="flex items-center">

                        <img src={cdacLogo} alt="AgriChat logo" className="h-9 w-12" />
                        <img src={logo} alt="AgriChat logo" className="h-12 w-12" />
                    </div>
                    <span
                        className="text-lg font-semibold tracking-wide text-white"
                        style={{ fontFamily: "'Poppins', sans-serif" }}
                    >
                        AgriChat
                    </span>
                </div>

                {/* headline */}
                <div className="relative z-10 flex flex-1 flex-col justify-center px-10 lg:px-14">
                    <div className="max-w-lg">
                        <span className="mb-5 inline-flex w-fit items-center gap-2 rounded-full border border-[#E5B65C]/30 bg-[#E5B65C]/10 px-3 py-1 text-xs font-medium text-[#E5B65C] backdrop-blur-sm">
                            <span className="h-1.5 w-1.5 rounded-full bg-[#E5B65C]" />
                            RAG-powered for Indian agriculture
                        </span>

                        <h1
                            className="text-4xl font-semibold leading-[1.15] text-white lg:text-[2.75rem]"
                            style={{ fontFamily: "'Poppins', sans-serif" }}
                        >
                            India&rsquo;s AI companion
                            <br />
                            for every farmer.
                        </h1>

                        <p className="mt-5 max-w-md text-[15px] leading-relaxed text-white/70">
                            Ask about fertilizer schedules, pest control,
                            irrigation plans, and government schemes —
                            grounded in real documents, answered in your
                            language.
                        </p>

                        {/* <div className="mt-8 flex flex-wrap gap-2.5">
                            {FEATURE_CHIPS.map((chip) => (
                                <span
                                    key={chip.label}
                                    className="flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.06] px-3.5 py-2 text-xs font-medium text-white/85 backdrop-blur-sm"
                                >
                                    <span aria-hidden="true">
                                        {chip.icon}
                                    </span>
                                    {chip.label}
                                </span>
                            ))}
                        </div> */}
                    </div>
                </div>

                {/* floating "live query" card, echoes the in-app RAG experience */}
                {/* <div className="agrichat-float absolute right-10 top-28 z-10 hidden w-72 rounded-2xl border border-white/10 bg-[#10162B]/70 p-4 shadow-2xl backdrop-blur-md xl:block">
                    <div className="flex items-center justify-between">
                        <span className="flex items-center gap-1.5 text-[11px] font-medium text-white/50">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                            Live
                        </span>
                        <span className="text-[11px] text-white/40">
                            Paddy · Pest ID
                        </span>
                    </div>

                    <p className="mt-3 text-sm text-white/90">
                        &ldquo;धान की फसल में सफ़ेद मक्खी दिख रही
                        है&rdquo;
                    </p>

                    <div className="mt-3 rounded-lg bg-white/5 px-3 py-2 text-xs text-[#E5B65C]">
                        Whitefly detected — advisory shared, follow-up
                        scheduled
                    </div>
                </div> */}

                {/* footer strip */}
                <div className="relative z-10 flex items-center gap-2 px-10 pb-10 text-xs text-white/40 lg:px-14 lg:pb-12">
                    <span className="h-1 w-1 rounded-full bg-[#E5B65C]" />
                    Built for kisan, in 22+ Indian languages
                </div>
            </div>

            {/* RIGHT: sign-in panel */}
            <div className="relative flex w-full flex-1 items-center justify-center overflow-hidden bg-[#EEF1F6] px-6 py-16">
                {/* faint brand watermark */}
                <img
                    src={logo}
                    aria-hidden="true"
                    className="pointer-events-none absolute -bottom-16 -right-16 h-72 w-72 opacity-[0.05]"
                />

                <div className="relative z-10 w-full max-w-md">
                    {/* mobile-only compact header (left panel is hidden below md) */}
                    <div className="mb-8 flex flex-col items-center gap-3 md:hidden">
                        <img src={logo} alt="AgriChat logo" className="h-12 w-12" />
                        <span
                            className="text-xl font-semibold text-[#10162B]"
                            style={{ fontFamily: "'Poppins', sans-serif" }}
                        >
                            AgriChat
                        </span>
                    </div>

                    <div className="rounded-3xl border border-black/5 bg-white p-8 shadow-[0_20px_60px_-15px_rgba(16,22,43,0.18)] sm:p-10">
                        <div className="mb-8 text-center">
                            <div className="mx-auto mb-3 flex items-center justify-center">
                                <img
                                    src={logo}
                                    alt=""
                                    className="h-24 w-24"
                                />
                            </div>

                            <h1
                                className="text-2xl font-semibold text-[#10162B]"
                                style={{ fontFamily: "'Poppins', sans-serif" }}
                            >
                                Welcome to AgriChat
                            </h1>

                            <p className="mt-2 text-sm text-gray-500">
                                Sign in to continue to your farming
                                assistant
                            </p>
                        </div>

                        <button
                            type="button"
                            onClick={handleGoogleLogin}
                            className="flex w-full cursor-pointer items-center justify-center gap-3 rounded-xl border border-gray-200 bg-white px-4 py-3.5 text-sm font-medium text-[#10162B] shadow-sm transition hover:border-gray-300 hover:shadow-md active:scale-[0.99]"
                        >
                            <svg
                                aria-hidden="true"
                                viewBox="0 0 24 24"
                                className="h-5 w-5"
                            >
                                <path
                                    fill="#4285F4"
                                    d="M21.35 12.27c0-.72-.06-1.42-.18-2.09H12v3.96h5.24a4.48 4.48 0 0 1-1.94 2.94v2.45h3.14c1.84-1.69 2.91-4.18 2.91-7.26Z"
                                />
                                <path
                                    fill="#34A853"
                                    d="M12 21.5c2.63 0 4.84-.87 6.45-2.36l-3.14-2.45c-.87.58-1.98.92-3.31.92-2.54 0-4.69-1.72-5.46-4.03H3.3v2.53A9.74 9.74 0 0 0 12 21.5Z"
                                />
                                <path
                                    fill="#FBBC05"
                                    d="M6.54 13.58A5.86 5.86 0 0 1 6.23 12c0-.55.11-1.09.31-1.58V7.89H3.3A9.5 9.5 0 0 0 2.5 12c0 1.53.37 2.98 1.03 4.11l3.01-2.53Z"
                                />
                                <path
                                    fill="#EA4335"
                                    d="M12 6.39c1.43 0 2.71.49 3.72 1.45l2.79-2.79C16.83 3.5 14.63 2.5 12 2.5a9.74 9.74 0 0 0-8.7 5.39l3.01 2.53C7.31 8.11 9.46 6.39 12 6.39Z"
                                />
                            </svg>

                            Continue with Google
                        </button>

                        <p className="mt-6 text-center text-xs leading-relaxed text-gray-400">
                            By continuing, you agree to AgriChat&rsquo;s{" "}
                            <a
                                href="/terms"
                                className="font-medium text-gray-500 underline underline-offset-2 hover:text-[#10162B]"
                            >
                                Terms
                            </a>{" "}
                            and{" "}
                            <a
                                href="/privacy"
                                className="font-medium text-gray-500 underline underline-offset-2 hover:text-[#10162B]"
                            >
                                Privacy Policy
                            </a>
                            .
                        </p>

                        {isError && (
                            <div className="mt-5 rounded-xl bg-amber-50 px-4 py-3 text-center text-sm text-amber-700 ring-1 ring-amber-100">
                                You are not currently signed in.
                            </div>
                        )}
                    </div>

                    <p className="mt-6 text-center text-xs text-gray-400">
                        Available in 22+ Indian languages · Fertilizer,
                        pest, irrigation & scheme guidance
                    </p>
                </div>
            </div>
        </main>
    );
}