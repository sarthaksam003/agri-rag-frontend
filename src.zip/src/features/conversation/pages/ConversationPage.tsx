import { useEffect } from "react";
import { useParams } from "react-router-dom";

import { ConversationView } from "@/features/conversation/components/ConversationView/ConversationView";
import { getMockConversation } from "@/features/conversation/services/mockConversation.repository";
import { useConversationStore } from "@/features/conversation/store/conversation.store";
import { getChatHistory } from "@/services/api";
import { DEFAULT_TENANT_ID } from "@/config/api";
export const ConversationPage = () => {
  const { conversationId } = useParams<{
    conversationId?: string;
  }>();
  console.log("URL conversationId:", conversationId);
  const setSessionId = useConversationStore(
    state => state.setSessionId
  );

  const setMessages = useConversationStore(
    state => state.setMessages
  );

  const clear = useConversationStore(
    state => state.clear
  );

  const setStatus = useConversationStore(
    state => state.setStatus
  );

  useEffect(() => {
    if (!conversationId) {
      return;
    }

    const loadHistory = async () => {
      try {
        setStatus("waiting");

        const data = await getChatHistory(
          conversationId,
          DEFAULT_TENANT_ID,
        );

        const history = data?.data?.history ?? [];

        const messages = history.flatMap(
          (
            item: {
              user: string;
              assistant: string;
            },
            index: number,
          ) => {
            const userMessage = {
              id: `${conversationId}-user-${index}`,
              conversationId,
              role: "user" as const,
              content: item.user,
              createdAt: new Date(),
              inputType: "text" as const,
              status: "completed" as const,
            };

            const assistantMessage = {
              id: `${conversationId}-assistant-${index}`,
              conversationId,
              role: "assistant" as const,
              content: item.assistant,
              createdAt: new Date(),
              inputType: "text" as const,
              status: "completed" as const,
            };

            return [userMessage, assistantMessage];
          },
        );

        setSessionId(data?.data?.session_id ?? conversationId);
        setMessages(messages);
        setStatus("idle");
      } catch (error) {
        console.error("Failed to load chat history:", error);
        setStatus("error");
      }
    };

    void loadHistory();
  }, [
    conversationId,
    setMessages,
    setSessionId,
    setStatus,
  ]);
  return <ConversationView />;
};