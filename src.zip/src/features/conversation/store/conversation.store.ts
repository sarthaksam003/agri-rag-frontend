import { ConversationStatus } from '@/features/conversation/types/conversation-status';
import { ChatMessage } from '@/features/conversation/types/message';
import { create } from 'zustand';

interface ConversationStore {
  messages: ChatMessage[];
  sessionId: string | null;
  status: ConversationStatus;
  error: unknown;

  ragMode: "simple" | "multiquery";
  sourceLanguage: string;

  setSessionId: (id: string | null) => void;

  setRagMode: (mode: "simple" | "multiquery") => void;
  setSourceLanguage: (lang: string) => void;

  setError: (error: unknown) => void;
  clearError: () => void;

  addMessage: (message: ChatMessage) => void;


  clear: () => void;


  setStatus: (status: ConversationStatus) => void
  setMessages: (messages: ChatMessage[]) => void,
}

export const useConversationStore = create<ConversationStore>((set, get) => ({
  // State
  messages: [],
  sessionId: null,
  error: null,
  ragMode: 'simple',
  sourceLanguage: 'or',    // ← top-level state
  status: "idle",
  // Actions
  setRagMode: (mode: "simple" | "multiquery") => set({ ragMode: mode }),
  setSourceLanguage: (lang) => set({ sourceLanguage: lang }),  // ← top-level action
  setError: (error) => set({ error }),
  clearError: () => set({ error: null }),
  clear: () =>
    set({
      messages: [],
      sessionId: null,
      error: null,
      status: "idle",
    }),
  addMessage: (message) =>
    set((state) => ({

      messages: [

        ...state.messages,

        message,

      ],

    })),



  setSessionId: (id) => set({ sessionId: id }),
  setMessages: (messages) => set({ messages }),
  setStatus: (status: ConversationStatus) =>
    set({
      status,
    }),
}));
