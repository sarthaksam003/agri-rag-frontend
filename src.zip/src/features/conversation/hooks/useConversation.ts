import { useCallback } from "react";
import { useNavigate } from "react-router-dom";

import { useConversationStore } from "@/features/conversation/store/conversation.store";
import { sendChatMessage } from "@/services/api";
import { DEFAULT_TENANT_ID } from "@/config/api";

export function useConversation() {
    const navigate = useNavigate();

    const {
        messages,
        addMessage,
        sessionId,
        setSessionId,
        setStatus,
    } = useConversationStore();


    const sendMessage = useCallback(
        async (
            text: string,
            inputType: "text" | "voice",
        ) => {
            const trimmedText = text.trim();

            if (!trimmedText) {
                return;
            }

            /*
             * The backend is the source of truth for session IDs.
             *
             * For a new conversation, sessionId is null.
             * The backend creates the session and returns its ID.
             */
            const activeSessionId = sessionId;

            const userMessage = {
                id: crypto.randomUUID(),
                conversationId: activeSessionId ?? "",
                role: "user" as const,
                content: trimmedText,
                createdAt: new Date(),
                inputType,
                status: "completed" as const,
            };

            addMessage(userMessage);
            setStatus("waiting");

            try {
                /*
                 * The current backend endpoint is the multi-query RAG
                 * endpoint. Voice input is not being integrated yet, so
                 * this first integration handles the text request path.
                 */
                if (inputType !== "text") {
                    throw new Error(
                        "Voice input is not connected to the backend yet.",
                    );
                }

                const data = await sendChatMessage(
                    trimmedText,
                    activeSessionId,
                    DEFAULT_TENANT_ID,
                );

                /*
                 * The backend creates the session ID when this is the
                 * first message. Store that ID for subsequent messages.
                 */
                const backendSessionId = data.session_id;

                if (!activeSessionId && backendSessionId) {
                    setSessionId(backendSessionId);
                    navigate(`/chat/${backendSessionId}`, {
                        replace: true,
                    });
                }

                const assistantMessage = {
                    id: data.id ?? crypto.randomUUID(),
                    conversationId: backendSessionId ?? activeSessionId ?? "",
                    role: "assistant" as const,
                    content: data.response,
                    createdAt: data.timestamp
                        ? new Date(data.timestamp)
                        : new Date(),
                    inputType: "text" as const,
                    status: "completed" as const,
                };

                addMessage(assistantMessage);
                setStatus("idle");
            } catch (error) {
                console.error("Failed to send chat message:", error);
                setStatus("error");
            }
        },
        [
            addMessage,
            navigate,
            sessionId,
            setSessionId,
            setStatus,
        ],
    );

    return {
        messages,
        status,
        sendMessage,
    };
}