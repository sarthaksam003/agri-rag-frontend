import styles from "./SidebarRail.module.css";
import { NavLink } from "react-router-dom";
import { useNewChat } from "@/features/conversation/hooks/useNewChat";

const RailNavigation = () => {
    const handleNewChat = useNewChat();
    return (
        <nav className={styles["navigation"]} id="railNav">
            <button
                type='button'
                className={styles.iconButton} onClick={handleNewChat} id="newChatBtn" data-view="new-chat" title="New Chat">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
                    <line x1="12" y1="5" x2="12" y2="19" />
                    <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
            </button>
            <NavLink
                to="/chat" className={({ isActive }) =>
                    isActive
                        ? `${styles.iconButton} ${styles.iconButtonActive}`
                        : styles.iconButton
                } data-view="chat" title="Chat"  >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                </svg>
            </NavLink>
            <NavLink
                to="/documents"
                className={({ isActive }) =>
                    isActive
                        ? `${styles.iconButton} ${styles.iconButtonActive}`
                        : styles.iconButton
                } data-view="documents" title="Documents"  >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                </svg>
            </NavLink>
            <NavLink to="/sessions" className={({ isActive }) =>
                isActive
                    ? `${styles.iconButton} ${styles.iconButtonActive}`
                    : styles.iconButton
            } data-view="sessions" title="Sessions"  >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                </svg>
            </NavLink>
            <NavLink to="/settings" className={({ isActive }) =>
                isActive
                    ? `${styles.iconButton} ${styles.iconButtonActive}`
                    : styles.iconButton
            } data-view="settings" title="Settings"  >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="3" />
                    <path
                        d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
                </svg>
            </NavLink>


        </nav>

    )
}

export default RailNavigation