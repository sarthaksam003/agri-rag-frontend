// import { useSidebarStore } from "@/features/navigation/sidebar.store";
import styles from "./SidebarTabs.module.css";
import {
    HiOutlineChatBubbleLeftRight,
    HiOutlineDocumentText,
    HiOutlineClock,
    HiOutlineCog6Tooth,
} from "react-icons/hi2";
import { NavLink } from "react-router-dom";

export const SidebarTabs = () => {
    return (
        <nav className={styles.nav}>
            <NavLink
                to="/chat"
                className={({ isActive }) =>
                    isActive
                        ? `${styles.navItem} ${styles.navItemActive}`
                        : styles.navItem
                }
            >
                <HiOutlineChatBubbleLeftRight />
                <span>Chat</span>
            </NavLink>

            <NavLink
                to="/documents"
                className={({ isActive }) =>
                    isActive
                        ? `${styles.navItem} ${styles.navItemActive}`
                        : styles.navItem
                }
            >
                <HiOutlineDocumentText />
                <span>Documents</span>
            </NavLink>

            <NavLink
                to="/sessions"
                className={({ isActive }) =>
                    isActive
                        ? `${styles.navItem} ${styles.navItemActive}`
                        : styles.navItem
                }
            >
                <HiOutlineClock />
                <span>Sessions</span>
            </NavLink>

            <NavLink
                to="/settings"
                className={({ isActive }) =>
                    isActive
                        ? `${styles.navItem} ${styles.navItemActive}`
                        : styles.navItem
                }
            >
                <HiOutlineCog6Tooth />
                <span>Settings</span>
            </NavLink>
        </nav>
    );
};